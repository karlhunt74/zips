package com.hunt.common.live_order_board;

/**
 * Enum to represent two sides on a board
 * 
 * @author karlhunt
 *
 */
public enum Side {
	B,
	S
}
