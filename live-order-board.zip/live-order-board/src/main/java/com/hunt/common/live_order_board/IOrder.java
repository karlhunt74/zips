package com.hunt.common.live_order_board;

/**
 * Represents an order
 * 
 * @author karlhunt
 * 
 */
public interface IOrder {

	int    getOrderId();
	Side   getSide();
	double getQuantity();
	double getPrice();
}
