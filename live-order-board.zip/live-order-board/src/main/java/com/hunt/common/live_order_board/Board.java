package com.hunt.common.live_order_board;

import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.summingDouble;

import java.util.Collections;
import java.util.Comparator;
import java.util.Map;

/**
 * Simple implementation of a Live Order Board.
 * 
 * Class provides method for adding an order to the board, as well as cancelling
 * Class also provides method for getting the "depth" of one side of the board
 * 
 * @author karlhunt
 *
 */
// Note : I would like to have spent some time profiling the performance of
//        using streams versus simple collections and loops as it's likely
//        that for very large volumes of data, streams, particularly the
//        collector could perform slightly worse; having said that, for coding
//        convenience and safety, given the requirement, the performance
//        trade off is acceptable.
public class Board implements IBoard {

	// create comparators as constants to improve performance
	private static final Comparator<Double> BUY_SIDE  = Collections.reverseOrder();
	private static final Comparator<Double> SELL_SIDE = Comparator.naturalOrder();
	
	// a collection to contain the rows in the Board
	private final Set<IOrder> rows = ConcurrentHashMap.newKeySet();

	/**
     * Add an order to the board
     * 
     * @param order order to be added
     */
	@Override
	public void addOrder(final IOrder order) {
		rows.add(order);
	}

	/**
     * Cancel an order from the board
     * 
     * @param orderId orderId to be cancelled
     * @returns true if the order exists
     */
	@Override
	public boolean cancelOrder(final int orderId) {
		return rows.removeIf(order -> order.getOrderId() == orderId);
	}

	/**
     * Get the depth of the board
     * 
     * @param side side of the depth requested
     * @returns map map of rows in the depth, keyed on price, with quantity as value
     */
	@Override
	public Map<Double, Double> getDepth(final Side side) {
		
		// filter the rows by side, collect, grouping by price
		// summing the quantity, using the comparator to sort
		return rows.stream().
				filter(order -> side.equals(order.getSide())).
				collect(groupingBy(
						IOrder::getPrice, 
						() -> new TreeMap<>(side.equals(Side.B) ? BUY_SIDE : SELL_SIDE),
						summingDouble(IOrder::getQuantity)));
	}
}
