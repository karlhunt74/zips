package com.hunt.common.live_order_board;

import java.util.Map;

/**
 * Represents a live order board
 * 
 * @author karlhunt
 * 
 */
public interface IBoard {

	void                addOrder(IOrder order);
	boolean             cancelOrder(int orderId);
	Map<Double, Double> getDepth(Side side);
}
