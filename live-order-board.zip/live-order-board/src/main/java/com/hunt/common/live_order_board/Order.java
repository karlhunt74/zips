package com.hunt.common.live_order_board;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Implementation of the IOrder interface
 * Represents an order which can be added to an IBoard implementation
 * 
 * @author karlhunt
 *
 */
public class Order implements IOrder {

	// typically we would do this more elegantly but
	// for the purposes of this code, this will suffice.
	private static final AtomicInteger ID_COUNTER = new AtomicInteger(1);
	
	// internal members
	private final int    orderId;
	private final int    userId;
	private final double quantity;
	private final double price;
	private final Side   side;
	
	/**
	 * Creates an {@code Order}
	 * 
	 * @param userId user creating the order
	 * @param quantity quantity of the order
	 * @param price price of the order
	 * @param side side of the order
	 */
	public Order(final int userId, final double quantity,
			     final double price, final Side side) {
		this.orderId  = ID_COUNTER.getAndIncrement();
		this.userId   = userId;
		this.quantity = quantity;
		this.price    = price;
		this.side     = side;
	}
	
	/**
	 * Returns the internally generated orderId
	 * 
	 * @return orderId created by the class
	 */
	@Override
	public int getOrderId() {
		return orderId;
	}

	/**
	 * Returns the userId provided by the constructor
	 * 
	 * @return userId userId provided to constructor
	 */
	public int getUserId() {
		return userId;
	}

	/**
	 * Returns the quantity provided by the constructor
	 * 
	 * @return quantity quantity provided to constructor
	 */
	public double getQuantity() {
		return quantity;
	}
	
	/**
	 * Returns the price provided by the constructor
	 * 
	 * @return price price provided to constructor
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * Returns the side provided by the constructor
	 * 
	 * @return side side provided to constructor
	 */
	public Side getSide() {
		return side;
	}
}
