package com.hunt.common.live_order_board;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class OrderTest {

	private static final int    ANY_USER_ID = 1;
	private static final double TEN         = 10d;
	private static final double ONE         = 1d;
	
	@Test
	public void test_constructor() throws Exception {
		
		// create an order
		Order order = new Order(ANY_USER_ID, TEN, ONE, Side.B);
		
		// assert user provided variables
		assertEquals(ANY_USER_ID, order.getUserId());
		assertEquals(TEN, order.getQuantity(), 0d);
		assertEquals(ONE, order.getPrice(), 0d);
		assertEquals(Side.B, order.getSide());
		
		// assert that the orderId is valid
		// note that we cannot guarantee the value
		// of this because of the fact that the
		// tests can run in parallel
		int id = order.getOrderId();
		assertNotNull(id);
		
		// create another order
		IOrder anotherOrder = new Order(ANY_USER_ID, TEN, ONE, Side.B);
		
		// assert that the orderId correctly increments
		assertTrue(anotherOrder.getOrderId() > id);
	}
}
