package com.hunt.common.live_order_board;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.Before;
import org.junit.Test;

public class BoardTest {
	
	// magic numbers
	private static final double ONE    = 1d;
	private static final double TWO    = 2d;
	private static final double THREE  = 3d;
	private static final double TEN    = 10d;
	private static final double TWENTY = 20d;
	
	// mock orders
	private final IOrder mockOrderBuyTenAtOne    = mock(IOrder.class);
	private final IOrder mockOrderBuyTenAtTwo    = mock(IOrder.class);
	private final IOrder mockOrder1BuyTenAtThree = mock(IOrder.class);
	private final IOrder mockOrder2BuyTenAtThree = mock(IOrder.class);
	private final IOrder mockOrderSellTenAtThree = mock(IOrder.class);
	private final IOrder mockOrder1SellTenAtOne  = mock(IOrder.class);
	private final IOrder mockOrder2SellTenAtOne  = mock(IOrder.class);
	
	@Before
	public void before() throws Exception {
		
		when(mockOrderBuyTenAtOne.getSide()).thenReturn(Side.B);
		when(mockOrderBuyTenAtOne.getQuantity()).thenReturn(TEN);
		when(mockOrderBuyTenAtOne.getPrice()).thenReturn(ONE);
		when(mockOrderBuyTenAtTwo.getSide()).thenReturn(Side.B);
		when(mockOrderBuyTenAtTwo.getQuantity()).thenReturn(TEN);
		when(mockOrderBuyTenAtTwo.getPrice()).thenReturn(TWO);
		when(mockOrder1BuyTenAtThree.getSide()).thenReturn(Side.B);
		when(mockOrder1BuyTenAtThree.getQuantity()).thenReturn(TEN);
		when(mockOrder1BuyTenAtThree.getPrice()).thenReturn(THREE);
		when(mockOrder2BuyTenAtThree.getSide()).thenReturn(Side.B);
		when(mockOrder2BuyTenAtThree.getQuantity()).thenReturn(TEN);
		when(mockOrder2BuyTenAtThree.getPrice()).thenReturn(THREE);
		when(mockOrderSellTenAtThree.getSide()).thenReturn(Side.S);
		when(mockOrderSellTenAtThree.getQuantity()).thenReturn(TEN);
		when(mockOrderSellTenAtThree.getPrice()).thenReturn(THREE);
		when(mockOrder1SellTenAtOne.getSide()).thenReturn(Side.S);
		when(mockOrder1SellTenAtOne.getQuantity()).thenReturn(TEN);
		when(mockOrder1SellTenAtOne.getPrice()).thenReturn(ONE);
		when(mockOrder2SellTenAtOne.getSide()).thenReturn(Side.S);
		when(mockOrder2SellTenAtOne.getQuantity()).thenReturn(TEN);
		when(mockOrder2SellTenAtOne.getPrice()).thenReturn(ONE);
	}
	
	@Test
	public void test_cancelOrder_returnsTrue_whenOrderExists() throws Exception {
	
		// create a new Board object
		IBoard board = new Board();
		
		// add an order to the board
		IOrder o = new Order(1, TEN, ONE, Side.B);
		board.addOrder(o);
		
		// assert that you can cancel the order
		assertTrue(board.cancelOrder(o.getOrderId()));
	}
	
	@Test
	public void test_cancelOrder_returnsFalse_whenOrderDoesNotExist() throws Exception {
		
		// create a new Board object
		IBoard board = new Board();
		
		// assert that you can cancel the order
		assertFalse(board.cancelOrder(1));
	}
	
	@Test
	public void test_getDepth_returnsNoRows_whenNoOrdersExist() throws Exception {
		
		Map<Double, Double> rows;
		
		// create a new Board object
		IBoard board = new Board();
		
		// get the rows from the board
		rows = board.getDepth(Side.B);
		
		// assert that there are no rows
		assertTrue(rows.isEmpty());
	}
	
	@Test
	public void test_getDepth_returnsRowBasedOnSingleOrder_whenOnlyOneBuyOrderExists() throws Exception {
		
		Map<Double, Double> rows;
		
		// create a new Board object
		IBoard board = new Board();
		
		// add an order to the board
		board.addOrder(mockOrderBuyTenAtOne);
		
		// get the rows from the board
		rows = board.getDepth(Side.B);
		
		// assert that there is one row
		// in the depth
		assertEquals(1, rows.size());
		
		//get an iterator over the rows
		Iterator<Entry<Double, Double>> iter = rows.entrySet().iterator();
		
		// get the row
		Entry<Double, Double> row = iter.next();
		
		// make assertions on the row
		assertEquals(ONE, row.getKey(), 1d);
		assertEquals(TEN, row.getValue(), 1d);
	}
	
	@Test
	public void test_getDepth_returnsCorrectlySortedRows_whenMultipleBuyOrdersExistAtDifferentPrices() throws Exception {
		
		Map<Double, Double> rows;
		
		// create a new Board object
		IBoard board = new Board();
		
		// add two orders to the board
		board.addOrder(mockOrderBuyTenAtOne);
		board.addOrder(mockOrderBuyTenAtTwo);
		
		// get the rows from the board
		rows = board.getDepth(Side.B);
		
		// assert that there are two rows
		// in the depth
		assertEquals(2, rows.size());
		
		//get an iterator over the rows
		Iterator<Entry<Double, Double>> iter = rows.entrySet().iterator();
		
		// get the first row
		Entry<Double, Double> row1 = iter.next();
		
		// make assertions on the row
		assertEquals(ONE, row1.getKey(), 1d);
		assertEquals(TEN, row1.getValue(), 1d);
		
		// get the second row
		Entry<Double, Double> row2 = iter.next();
		
		// make assertions on the row
		assertEquals(TWO, row2.getKey(), 1d);
		assertEquals(TEN, row2.getValue(), 1d);
	}
	
	@Test
	public void test_getDepth_returnsCorrectlyConsolidatedOrders_whenMultipleBuyOrdersExistAtSamePrices() throws Exception {
		
		Map<Double, Double> rows;
		
		// create a new Board object
		IBoard board = new Board();
		
		// add two orders to the board
		board.addOrder(mockOrder1BuyTenAtThree);
		board.addOrder(mockOrder2BuyTenAtThree);
		
		// get the rows from the board
		rows = board.getDepth(Side.B);
		
		// assert that there is one row in the depth
		assertEquals(1, rows.size());
		
		//get an iterator over the rows
		Iterator<Entry<Double, Double>> iter = rows.entrySet().iterator();
		
		// get the row
		Entry<Double, Double> row = iter.next();
		
		// make assertions on the row
		assertEquals(THREE,  row.getKey(), 1d);
		assertEquals(TWENTY, row.getValue(), 1d);
	}
	
	@Test
	public void test_getDepth_returnsCorrectlySortedAndConsolidatedRows_whenMultipleSellOrdersExistAtCombinationPrices() throws Exception {
		
		Map<Double, Double> rows;
		
		// create a new Board object
		Board board = new Board();
		
		// add three orders to the board
		board.addOrder(mockOrderSellTenAtThree);
		board.addOrder(mockOrder1SellTenAtOne);
		board.addOrder(mockOrder2SellTenAtOne);
		
		// get the rows from the board
		rows = board.getDepth(Side.S);
		
		// assert that there are two rows in the depth
		assertEquals(2, rows.size());
		
		//get an iterator over the rows
		Iterator<Entry<Double, Double>> iter = rows.entrySet().iterator();
		
		// get the first row
		Entry<Double, Double> row1 = iter.next();
		
		// make assertions on the row
		assertEquals(ONE, row1.getKey(), 1d);
		assertEquals(TWENTY, row1.getValue(), 1d);
		
		// get the second row
		Entry<Double, Double> row2 = iter.next();
		
		// make assertions on the row
		assertEquals(THREE, row2.getKey(), 1d);
		assertEquals(TEN, row2.getValue(), 1d);
	}
}
